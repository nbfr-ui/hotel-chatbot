import logging
import os
import openai

openai.api_key = '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'
os.environ["OPENAI_API_KEY"] = openai.api_key


class ChatGptAdapter:
    def chat_completion(self, messages, temperature = 1) -> str:
        try:
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo-0613",
                messages=messages,
                temperature=temperature
            )
            response_message = response["choices"][0]["message"]
            return response_message.content

        except Exception as e:
            logging.error(e)
            return "Sorry. There was an issue transmitting the message. Could you repeat please?"

