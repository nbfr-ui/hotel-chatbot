class SessionInfo:
    def __init__(self,  messages: list, booking_confirmation_sent: bool):
        print("2. Initialize the new instance of Point.")
        self.messages = messages
        self.booking_confirmation_sent = booking_confirmation_sent
